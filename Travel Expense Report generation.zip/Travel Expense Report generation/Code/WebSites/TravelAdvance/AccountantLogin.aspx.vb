﻿
Partial Class AccountantLogin
    Inherits System.Web.UI.Page

End Class
