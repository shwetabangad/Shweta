﻿
Partial Class Travel_Advance
    Inherits System.Web.UI.Page

End Class
