package com.java.towing.numberplate;

public class PositionInPlate { 
    public int x1;
    public int x2;
    PositionInPlate(int x1,int x2) {
        this.x1 = x1;
        this.x2 = x2;
    }
}