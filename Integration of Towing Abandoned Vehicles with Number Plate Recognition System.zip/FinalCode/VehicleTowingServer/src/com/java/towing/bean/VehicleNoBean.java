package com.java.towing.bean;

public class VehicleNoBean {

	private int vehicle_no_id;
	private String vehicle_number;
	private int vehicle_user_id;
	private String vehicle_type;
	public int getVehicle_no_id() {
		return vehicle_no_id;
	}
	public void setVehicle_no_id(int vehicle_no_id) {
		this.vehicle_no_id = vehicle_no_id;
	}
	public String getVehicle_number() {
		return vehicle_number;
	}
	public void setVehicle_number(String vehicle_number) {
		this.vehicle_number = vehicle_number;
	}
	public int getVehicle_user_id() {
		return vehicle_user_id;
	}
	public void setVehicle_user_id(int vehicle_user_id) {
		this.vehicle_user_id = vehicle_user_id;
	}
	public String getVehicle_type() {
		return vehicle_type;
	}
	public void setVehicle_type(String vehicle_type) {
		this.vehicle_type = vehicle_type;
	}

	
}
