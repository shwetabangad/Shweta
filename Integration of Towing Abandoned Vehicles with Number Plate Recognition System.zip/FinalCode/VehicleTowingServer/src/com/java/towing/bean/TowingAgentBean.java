package com.java.towing.bean;

public class TowingAgentBean {

	private int towing_agent_id;
	private String towing_agent_firstname;
	private String towing_agente_lastname;
	private String towing_agent_gender;
	private String towing_agent_address;
	private String towing_agent_mobileno;
	private String towing_agent_emailid;
	private String towing_agente_username;
	private String towing_agent_password;
	private Double towing_agent_register_lat;
	private Double towing_agent_register_long;
	private Double towing_agent_current_lat;
	private Double towing_agent_current_long;
	public int getTowing_agent_id() {
		return towing_agent_id;
	}
	public void setTowing_agent_id(int towing_agent_id) {
		this.towing_agent_id = towing_agent_id;
	}
	public String getTowing_agent_firstname() {
		return towing_agent_firstname;
	}
	public void setTowing_agent_firstname(String towing_agent_firstname) {
		this.towing_agent_firstname = towing_agent_firstname;
	}
	public String getTowing_agente_lastname() {
		return towing_agente_lastname;
	}
	public void setTowing_agente_lastname(String towing_agente_lastname) {
		this.towing_agente_lastname = towing_agente_lastname;
	}
	public String getTowing_agent_gender() {
		return towing_agent_gender;
	}
	public void setTowing_agent_gender(String towing_agent_gender) {
		this.towing_agent_gender = towing_agent_gender;
	}
	public String getTowing_agent_address() {
		return towing_agent_address;
	}
	public void setTowing_agent_address(String towing_agent_address) {
		this.towing_agent_address = towing_agent_address;
	}
	public String getTowing_agent_mobileno() {
		return towing_agent_mobileno;
	}
	public void setTowing_agent_mobileno(String towing_agent_mobileno) {
		this.towing_agent_mobileno = towing_agent_mobileno;
	}
	public String getTowing_agent_emailid() {
		return towing_agent_emailid;
	}
	public void setTowing_agent_emailid(String towing_agent_emailid) {
		this.towing_agent_emailid = towing_agent_emailid;
	}
	public String getTowing_agente_username() {
		return towing_agente_username;
	}
	public void setTowing_agente_username(String towing_agente_username) {
		this.towing_agente_username = towing_agente_username;
	}
	public String getTowing_agent_password() {
		return towing_agent_password;
	}
	public void setTowing_agent_password(String towing_agent_password) {
		this.towing_agent_password = towing_agent_password;
	}
	public Double getTowing_agent_register_lat() {
		return towing_agent_register_lat;
	}
	public void setTowing_agent_register_lat(Double towing_agent_register_lat) {
		this.towing_agent_register_lat = towing_agent_register_lat;
	}
	public Double getTowing_agent_register_long() {
		return towing_agent_register_long;
	}
	public void setTowing_agent_register_long(Double towing_agent_register_long) {
		this.towing_agent_register_long = towing_agent_register_long;
	}
	public Double getTowing_agent_current_lat() {
		return towing_agent_current_lat;
	}
	public void setTowing_agent_current_lat(Double towing_agent_current_lat) {
		this.towing_agent_current_lat = towing_agent_current_lat;
	}
	public Double getTowing_agent_current_long() {
		return towing_agent_current_long;
	}
	public void setTowing_agent_current_long(Double towing_agent_current_long) {
		this.towing_agent_current_long = towing_agent_current_long;
	}

	
}
