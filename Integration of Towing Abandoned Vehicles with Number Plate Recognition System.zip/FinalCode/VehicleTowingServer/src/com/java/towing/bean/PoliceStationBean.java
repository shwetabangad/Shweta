package com.java.towing.bean;

public class PoliceStationBean {
	
	private int policeStationId;
	private String policeStationName;
	private String policeStationAddress;
	private Double policeStationLat;
	private Double policeStationLong;
	
	
	
	
	public int getPoliceStationId() {
		return policeStationId;
	}
	public void setPoliceStationId(int policeStationId) {
		this.policeStationId = policeStationId;
	}
	public String getPoliceStationName() {
		return policeStationName;
	}
	public void setPoliceStationName(String policeStationName) {
		this.policeStationName = policeStationName;
	}
	public String getPoliceStationAddress() {
		return policeStationAddress;
	}
	public void setPoliceStationAddress(String policeStationAddress) {
		this.policeStationAddress = policeStationAddress;
	}
	public Double getPoliceStationLat() {
		return policeStationLat;
	}
	public void setPoliceStationLat(Double policeStationLat) {
		this.policeStationLat = policeStationLat;
	}
	public Double getPoliceStationLong() {
		return policeStationLong;
	}
	public void setPoliceStationLong(Double policeStationLong) {
		this.policeStationLong = policeStationLong;
	}
	
	
	
	

}
